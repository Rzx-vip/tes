module.exports = {
  meta: {
    category: "Downloader",
    name: "Instagram Downloader",
    method: "GET",
    path: "/api/downloader/instagram",
    description: "Endpoint plugin demo untuk mengambil metadata media Instagram dari sebuah URL.",
    params: [
      {
        name: "url",
        label: "Instagram URL",
        type: "text",
        required: true,
        placeholder: "https://www.instagram.com/reel/..."
      }
    ],
    example: {
      url: "https://www.instagram.com/reel/demo/"
    }
  },

  async run({ query }) {
    const url = query.url;
    if (!url) throw new Error("Parameter url wajib diisi.");

    return {
      status: true,
      data: {
        platform: "instagram",
        url,
        type: /\/reel\//i.test(url) ? "reel" : "media",
        title: "Demo Instagram Result",
        thumbnail: "https://example.com/thumbnail.jpg",
        media: {
          quality: "HD",
          format: "mp4"
        }
      },
      logs: [
        "[plugin] Instagram Downloader",
        "[validate] url parameter OK",
        "[scraper] demo resolver executed",
        "[response] metadata ready"
      ]
    };
  }
};
