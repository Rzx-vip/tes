module.exports = {
  meta: {
    category: "Downloader",
    name: "TikTok Downloader",
    method: "GET",
    path: "/api/downloader/tiktok",
    description: "Endpoint plugin demo untuk metadata video TikTok.",
    params: [
      {
        name: "url",
        label: "TikTok URL",
        type: "text",
        required: true,
        placeholder: "https://www.tiktok.com/@user/video/..."
      }
    ],
    example: {
      url: "https://www.tiktok.com/@demo/video/1234567890"
    }
  },

  async run({ query }) {
    const url = query.url;
    if (!url) throw new Error("Parameter url wajib diisi.");

    return {
      status: true,
      data: {
        platform: "tiktok",
        url,
        title: "Demo TikTok Result",
        author: {
          username: "@demo",
          nickname: "Igneel Demo"
        },
        media: {
          watermark: false,
          quality: "HD",
          format: "mp4"
        }
      },
      logs: [
        "[plugin] TikTok Downloader",
        "[validate] url parameter OK",
        "[scraper] demo resolver executed",
        "[response] media metadata ready"
      ]
    };
  }
};
