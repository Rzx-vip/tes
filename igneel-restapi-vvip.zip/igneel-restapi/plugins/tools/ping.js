module.exports = {
  meta: {
    category: "Tools",
    name: "Ping",
    method: "GET",
    path: "/api/tools/ping",
    description: "Memeriksa status API, author, version, dan waktu server.",
    params: [],
    example: {}
  },

  async run() {
    return {
      status: true,
      data: {
        message: "Pong!",
        serverTime: new Date().toISOString(),
        node: process.version
      },
      logs: [
        "[plugin] Ping",
        "[health] server online",
        "[response] 200 OK"
      ]
    };
  }
};
