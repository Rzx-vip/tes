const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const ROOT = __dirname;
const PLUGINS_DIR = path.join(ROOT, "plugins");
const PORT = Number(process.env.PORT || 3000);
const AUTHOR = "Igneel";
const VERSION = "1.0.0";

function json(res, code, payload) {
  const data = JSON.stringify(payload, null, 2);
  res.writeHead(code, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Cache-Control": "no-store"
  });
  res.end(data);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => {
      data += chunk;
      if (data.length > 2_000_000) reject(new Error("Body too large"));
    });
    req.on("end", () => {
      if (!data) return resolve({});
      const type = String(req.headers["content-type"] || "");
      if (type.includes("application/json")) {
        try { return resolve(JSON.parse(data)); }
        catch { return reject(new Error("Invalid JSON body")); }
      }
      resolve(data);
    });
    req.on("error", reject);
  });
}

function walk(dir) {
  const out = [];
  if (!fs.existsSync(dir)) return out;
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, item.name);
    if (item.isDirectory()) out.push(...walk(full));
    else if (item.isFile() && item.name.endsWith(".js")) out.push(full);
  }
  return out;
}

function safeMeta(plugin, file) {
  const m = plugin && plugin.meta ? plugin.meta : {};
  if (!m.path || !m.name) return null;
  return {
    category: m.category || path.basename(path.dirname(file)),
    name: m.name,
    method: String(m.method || "GET").toUpperCase(),
    path: m.path.startsWith("/") ? m.path : "/" + m.path,
    description: m.description || "",
    params: Array.isArray(m.params) ? m.params : [],
    example: m.example || {},
    file: path.relative(ROOT, file).replaceAll(path.sep, "/")
  };
}

function loadPlugins() {
  const map = new Map();
  const files = walk(PLUGINS_DIR);
  for (const file of files) {
    try {
      delete require.cache[require.resolve(file)];
      const plugin = require(file);
      const meta = safeMeta(plugin, file);
      if (!meta || typeof plugin.run !== "function") continue;
      map.set(meta.path, { ...plugin, meta, file });
    } catch (err) {
      console.error("[plugin:error]", file, err.message);
    }
  }
  return map;
}

function makeCatalog(plugins) {
  const endpoints = [...plugins.values()].map(p => p.meta).sort((a,b) =>
    a.category.localeCompare(b.category) || a.name.localeCompare(b.name)
  );
  return {
    success: true,
    author: AUTHOR,
    version: VERSION,
    baseUrl: "",
    categories: [...new Set(endpoints.map(e => e.category))],
    endpoints
  };
}

function startServer() {
  const plugins = loadPlugins();

  const server = http.createServer(async (req, res) => {
    const parsed = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    const pathname = parsed.pathname;

    if (req.method === "OPTIONS") {
      res.writeHead(204, {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
      });
      return res.end();
    }

    if (pathname === "/api/catalog") {
      return json(res, 200, { ...makeCatalog(plugins), baseUrl: `http://${req.headers.host}` });
    }

    const plugin = plugins.get(pathname);
    if (plugin) {
      const allowed = String(plugin.meta.method || "GET").toUpperCase();
      if (allowed !== req.method) {
        return json(res, 405, {
          success:false, code:405, author:AUTHOR, status:false,
          message:`Method ${req.method} not allowed. Use ${allowed}.`,
          allowedMethod:allowed, logs:["method_not_allowed"]
        });
      }

      const started = Date.now();
      try {
        const query = Object.fromEntries(parsed.searchParams.entries());
        const body = await readBody(req);
        const context = {
          req,
          query,
          body,
          params: { ...query, ...(body && typeof body === "object" ? body : {}) },
          meta: plugin.meta
        };
        const result = await plugin.run(context);
        const elapsed = Date.now() - started;

        return json(res, 200, {
          success:true,
          code:200,
          author: result?.author || AUTHOR,
          status: result?.status !== false,
          ms: elapsed,
          data: result?.data ?? result ?? {},
          logs: Array.isArray(result?.logs) ? result.logs : [
            `[plugin] ${plugin.meta.name}`,
            "[request] completed",
            "[response] 200 OK"
          ]
        });
      } catch (err) {
        const elapsed = Date.now() - started;
        return json(res, 500, {
          success:false,
          code:500,
          author:AUTHOR,
          status:false,
          ms:elapsed,
          message:err.message || "Internal server error",
          logs:[
            `[plugin] ${plugin.meta.name}`,
            "[response] 500 INTERNAL_SERVER_ERROR"
          ]
        });
      }
    }

    if (pathname.startsWith("/api/")) {
      return json(res, 404, {
        success:false, code:404, author:AUTHOR, status:false,
        message:"Endpoint tidak ditemukan.",
        logs:["route_not_found"]
      });
    }

    // Static file serving: single-file frontend.
    let file = pathname === "/" ? "/index.html" : pathname;
    const filePath = path.join(ROOT, file);
    if (!filePath.startsWith(ROOT) || !fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
      return json(res, 404, {success:false,code:404,author:AUTHOR,status:false,message:"File not found."});
    }

    const ext = path.extname(filePath);
    const types = {
      ".html":"text/html; charset=utf-8",
      ".css":"text/css; charset=utf-8",
      ".js":"application/javascript; charset=utf-8",
      ".json":"application/json; charset=utf-8"
    };
    res.writeHead(200, {"Content-Type":types[ext] || "application/octet-stream"});
    fs.createReadStream(filePath).pipe(res);
  });

  server.listen(PORT, () => {
    console.log(`\nIgneel REST API running at http://localhost:${PORT}`);
    console.log(`Plugin folder: ${PLUGINS_DIR}\n`);
  });
}

startServer();
