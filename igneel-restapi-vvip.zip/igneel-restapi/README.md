# Igneel REST API Dashboard

Paket ini memakai `index.html` sebagai frontend tunggal (CSS + JavaScript sudah menyatu) dan `server.js` sebagai loader API.

## Struktur

```text
igneel-restapi/
├─ index.html
├─ server.js
├─ package.json
├─ README.md
└─ plugins/
   ├─ downloader/
   │  ├─ instagram.js
   │  └─ tiktok.js
   └─ tools/
      └─ ping.js
```

## Menjalankan

Node.js 18+:

```bash
cd igneel-restapi
npm start
```

Buka:

```text
http://localhost:3000
```

## Menambah endpoint

Buat file `.js` di kategori yang diinginkan, contoh:

```text
plugins/downloader/youtube.js
```

Gunakan format CommonJS:

```js
module.exports = {
  meta: {
    category: "Downloader",
    name: "YouTube Downloader",
    method: "GET",
    path: "/api/downloader/youtube",
    description: "Ambil data dari URL YouTube.",
    params: [
      {
        name: "url",
        label: "YouTube URL",
        type: "text",
        required: true,
        placeholder: "https://www.youtube.com/watch?v=..."
      }
    ],
    example: {
      url: "https://www.youtube.com/watch?v=demo"
    }
  },

  async run({ query }) {
    const url = query.url;
    if (!url) throw new Error("Parameter url wajib diisi.");

    // Pasang logic scraper / API milikmu di sini.
    return {
      status: true,
      data: {
        url,
        title: "Demo result",
        format: "mp4"
      },
      logs: [
        "[plugin] YouTube Downloader",
        "[scraper] processing url",
        "[response] data ready"
      ]
    };
  }
};
```

Setiap file `.js` yang valid akan discan otomatis ketika server dimulai. Kategori diambil dari `meta.category` atau nama folder jika kategori tidak ditulis.

## Envelope response

Berhasil:

```json
{
  "success": true,
  "code": 200,
  "author": "Igneel",
  "status": true,
  "ms": 42,
  "data": {},
  "logs": []
}
```

Error route:

```json
{
  "success": false,
  "code": 404,
  "author": "Igneel",
  "status": false,
  "message": "Endpoint tidak ditemukan.",
  "logs": ["route_not_found"]
}
```

Catatan: plugin contoh hanya demo metadata; ganti isi `run()` dengan scraper/API yang memang kamu gunakan dan pastikan penggunaan target web mematuhi aturan situs terkait.
